/**
 * !criar três objetos mouse, contendo peso tamanha e valor e nome do produto
 * !criar um carrinho que recebe nome e preço do produto ao click
 * !criar um botão adicionar ao carrinho
 * !criar um botão de compra que esvazia o carrinho
 * !Fazer o productCard
 * !Fazer o o addCart
 * !Fazer o Cart
 * !Somar os valores do Cart
 * !
 * !Não esquecer do quantity + 1
 */

const mouse1 = {
  id: 1,
  nome: 'HyperX Pulsefire',
  peso: '78g',
  valor: 99.99,
};
const mouse2 = {
  id: 2,
  nome: 'Red Dragon Predator',
  peso: '89g',
  valor: 127.50,
};
const mouse3 = {
  id: 3,
  nome: 'Red Dragon Cobra',
  peso: '73g',
  valor: 110.00,
};
const productCards = document.getElementById('Products');

// eslint-disable-next-line no-unused-vars
function addToCart(product) {
  const cart = document.getElementById('cart');
  cart.innerHTML = `<p>${product.nome}, $${product.valor}</p>`;
  return true;
}

productCards.innerHTML = `
<p>${mouse1.nome}</p>
<p>${mouse1.peso}</p> 
<p>${mouse1.valor}</p>

<button type="button" id="addPulsefire" onclick="addToCart(${mouse1})">
Adicionar ao carrinho
</button>

<p>${mouse2.nome}</p>
<p>${mouse2.peso}</p> 
<p>${mouse2.valor}</p>

<button type="button" id="addPredator" onclick="addToCart(${mouse2})">
Adicionar ao carrinho
</button>

<p>${mouse3.nome}</p>
<p>${mouse3.peso}</p> 
<p>${mouse3.valor}</p>

<button type="button" id="addCobra" onclick="addToCart(${mouse3})">
Adicionar ao carrinho
    </button>
    `;
