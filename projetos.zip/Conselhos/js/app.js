const randonAdvice = Math.floor(Math.random() * 200) + 1;
const getAdvice = async () => {
    const response = await fetch(`https://api.adviceslip.com/advice/${randonAdvice}`)
    const advice = await response.json()
    console.log(advice)

    const postAdvice = () => {
        const postAdvice = document.querySelector('.advices')
        postAdvice.innerHTML = `<h2>${advice.slip.advice}<h2>`
    }
    postAdvice()
};
getAdvice()
