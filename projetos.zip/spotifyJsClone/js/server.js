// Load the http library Carrega a bibliotéca http
const http = require('http');

// criar um http para lidar com as respostas

http
.createServer(function(request, response) {
response.writeHead(200, {'Content-Type': 'text/plain'});
response.write('Hello World');
response.end();
}).listen(8888)
// esse código cria um servidor simples em sua maquina local
