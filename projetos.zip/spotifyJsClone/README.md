# Spotify Web API Examples

## Contents

- [Authentication examples](/authentication/)
    - [Authorization code]( /authentication/authorization_code/)
    - [Client Credentials](/authentication/client_credentials)
    - [Implicit Grant](/authentication/implicit_grant/)
- [Get User Profile example](/get_user_profile/)
