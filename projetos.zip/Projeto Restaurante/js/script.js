const deruny = {
    id: 1,
    nome: "Deruny",
    valor: 15.00
};
const holubtsi = {
    id: 2,
    nome: "Holubtsi",
    valor: 25.00
}
const pyrizhky = {
    id: 3,
    nome:"Pyrizhky",
    vlaor: 25.00
}

function addToComanda () {
    const comanda = document.getElementById("comanda")
    comanda.innerHTML = `<p> ${deruny.nome}, $${deruny.valor}</p>`
}