let segundos = 0
let minutos = 0
let horas = 0

function timerSegundos (segundos){setInterval (function (segundos) {
    if (segundos < 60) {
        return segundos ++ 
    }
}, 1000)}
console.log(timerSegundos(segundos))