const botao = document.getElementById("addTaref");
const addTaref = document.getElementById("tarefInput");
const lista = document.getElementById("tarefs")

function creatLi() {
    const lista = document.createElement("li")
    return lista;
}

function criaTarefa(textoInput) {
    const lista = creatLi();
    lista.innerHTML = textoInput; 
    lista.appendChild(lista);
} 

botao.addEventListener("click", function() {
    if (!addTaref.value)return;
    criaTarefa(addTaref.value)}
)

document.addEventListener("click", function () {

})