const selectDiv = document.querySelector(".temps")

const getTemp = async () => {
    const temp = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Curitiba&appid=0812aca61bfe2e569c8451f63f6b7765`)
    .then( () => { const response = temp.json()
    console.log(response)
});
}
getTemp()
