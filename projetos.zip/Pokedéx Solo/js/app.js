const pokemons = 'https://pokeapi.co/api/v2/pokemon/'

const getPokemons = async () => {
    const response = await fetch(pokemons)
    const data = await response.json()
    return data.results
};

const getPokemonsInfo = async (data) => {
        const data = 'https://pokeapi.co/api/v2/pokemon/results'
        const response = await fetch(data)
        const data = await response.json()
        return data;
    };
    
    console.log(getPokemons(),getPokemonsInfo())