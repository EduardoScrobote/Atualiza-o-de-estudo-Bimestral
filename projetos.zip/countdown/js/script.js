
/*
    !! IMPORTANT !!

    TODO: Criar uma função pegue o valor do input; / pegar uma data para a contagem ex: quero uma contagem até 01/01/2023
    TODO: Criar uma função que formate os dados acima para uma data real;
    TODO: Criar uma função que pegue e subtraia as anos;
    TODO: Criar uma função que pegue e subtraia as messes;
    TODO: Criar uma função que pegue e subtraia os dias;
    TODO: Criar uma função que junte tudo e mostre na tela;
    
    !! DICAS !!

    * Para pegar o valor do input, use o método .value;
    * Para separar os dados, use o método .split("/");
    * Para transformar em data crie uma string que retorne a seguinte formatação MM-DD-YYYY e adicione esta string em um new Date();
    
    ? Transforme a data em timestamp e subtraia o timestamp atual;
*/
 const date = document.getElementById("date");

const getDate = date.value;

function realData (getDate) {
    data = new Date(getDate)
    return data
}