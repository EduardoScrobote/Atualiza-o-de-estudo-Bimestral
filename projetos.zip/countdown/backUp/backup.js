function getDay () {
    const day = parseInt(getDate.value.split("/")[0]);
    return day
 };
function getMonth () {
    const month = parseInt(getDate.value.split("/")[1]);
 return month
}
function getYear () {
    const year = parseInt(getDate.value.split("/")[2])
    return year
}
function getFullDate () {
    return new Date(`${getDay()}/${getMonth()}/${getYear()}`)
}
getFullDate()

function getToday (){
    const day = new Date().getDate()
    const month = new Date().getMonth()
    const year = new Date().getFullYear()
    const today = `${day}/${month}/${year}`
    console.log(today)
    return new Date(today); 
}

function getRealYear () {
    const realYear = new Date().getFullYear
    return realYear
}

function getDays () {
    const nowDay = new Date().getDate();
    return nowDay
}

function display () {
    let countDown = document.getElementById("container")
    countDown.innerHTML = `<p id="countDown"></p>`;
}   
display()

function getDayOfYear(date) {
    const start = new Date(date.getFullYear(), 0, 0);
    const diff = date - start;
    const oneDay = 1000 * 60 * 60 * 24;
    const day = Math.floor(diff / oneDay);
    console.log('Day of year: ' + day);
    return day
}
function yearDifference () {
    return parseInt(getFullDate().getYear()) -  parseInt(getToday().getRealYear()) 
}
function daysDifference () {
    return parseInt(getDays) - parseInt(getDay())
}
console.log(parseInt(yearDifference()), parseInt(daysDifference()));

const button = document.getElementById("button")
button.addEventListener("click", () => console.log(yearDifference(), daysDifference()));